import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from anpars.str import turkce_karakter_cevir, slugify
from anpars.fs import klasor_agaci, otomatik_dosya_ismi_uret
from anpars.smart import akilli_donusum
from anpars.net import internet_var_mi, basit_get_istegi

def main():
    print("=== AnPars Quickstart Örneği ===\n")

    metin = "İstanbul'da güzel bir Çalışma günü!"
    print("Orijinal metin:", metin)
    print("Türkçe karakter çevrimi:", turkce_karakter_cevir(metin))
    print("Slugify sonucu:", slugify(metin))
    print()

    print("Bulunduğun klasörün dosya ağacı:\n", klasor_agaci("."))
    yeni_dosya = otomatik_dosya_ismi_uret(".", "rapor.txt")
    print("Otomatik oluşturulan dosya adı:", yeni_dosya)
    print()

    degerler = ["123", "45.67", "true", "2025-07-10", '{"a":1}', "merhaba"]
    for d in degerler:
        donusum = akilli_donusum(d)
        print(f'"{d}" → {donusum} (tip: {type(donusum)})')
    print()

    print("İnternet bağlantısı var mı?:", internet_var_mi())
    url = "http://www.google.com"
    icerik = basit_get_istegi(url)
    if icerik:
        print(f"{url} içeriği (ilk 100 karakter):\n{icerik[:100]}")
    else:
        print(f"{url} içeriği alınamadı.")
    print()

if __name__ == "__main__":
    main()
