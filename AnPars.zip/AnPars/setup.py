from setuptools import setup, find_packages  # Kurulum için gerekli modüller

setup(
    name="anpars",  # Paket ismi, pip install anpars gibi kullanılabilir
    version="0.1.0",  # Başlangıç sürüm numarası
    packages=find_packages(),  # anpars ve alt modüllerini otomatik bulur
    install_requires=[
        # Dış bağımlılıklar (şu anda gerekmiyor)
        # "requests>=2.25.1",  # örnek
    ],
    author="Akif Arpaç",  # Geliştirici ismi
    author_email="akif@example.com",  # (gerçek e-posta eklersen pypi için anlamlı olur)
    description="AnPars: Python ile dosya, ağ, metin ve veri tipleri için yardımcı araçlar.",  # Kısa açıklama
    long_description="Bu kütüphane; dosya işlemleri, metin dönüştürme, ağ kontrolü ve akıllı veri türü dönüşümleri gibi işlemleri kolaylaştırmak için geliştirilmiştir.",  # Daha uzun açıklama
    long_description_content_type="text/plain",  # Açıklama düz yazıysa text/plain, README.md ise text/markdown
    url="https://github.com/akifarpac/anpars",  # GitHub adresin varsa buraya yaz
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",  # Lisans türü (MIT önerilir)
    ],
    python_requires=">=3.6",  # Çalışması için gereken minimum Python sürümü
)
