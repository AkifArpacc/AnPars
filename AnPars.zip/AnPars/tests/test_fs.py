import unittest
import tempfile
import os
from pathlib import Path
from anpars.fs import FsUtils

class TestFsUtils(unittest.TestCase):
    def setUp(self):
        self.test_dir = tempfile.TemporaryDirectory()
        self.yedek_dir = Path(self.test_dir.name) / "yedekler"
        self.test_file_path = Path(self.test_dir.name) / "testfile.txt"
        with open(self.test_file_path, "w") as f:
            f.write("deneme içeriği")

    def tearDown(self):
        self.test_dir.cleanup()

    def test_klasor_agaci(self):
        agac = FsUtils.klasor_agaci(self.test_dir.name, derinlik=1)
        self.assertIn("testfile.txt", agac)

    def test_otomatik_dosya_ismi_uret(self):
        yeni_adi = FsUtils.otomatik_dosya_ismi_uret(self.test_dir.name, "testfile.txt")
        self.assertTrue(yeni_adi != "testfile.txt")
        self.assertTrue(yeni_adi.startswith("testfile("))

    def test_dosya_yedekle(self):
        yedek_yolu = FsUtils.dosya_yedekle(str(self.test_file_path), str(self.yedek_dir))
        self.assertIsNotNone(yedek_yolu)
        self.assertTrue(Path(yedek_yolu).exists())

        # Aynı dosyayı tekrar yedekle, farklı isim olmalı
        yedek_yolu2 = FsUtils.dosya_yedekle(str(self.test_file_path), str(self.yedek_dir))
        self.assertNotEqual(yedek_yolu, yedek_yolu2)

    def test_dosya_boyutu_okunabilir(self):
        boyut_str = FsUtils.dosya_boyutu_okunabilir(str(self.test_file_path))
        self.assertRegex(boyut_str, r"^\d+\.\d{2} (B|KB|MB|GB|TB)$")

if __name__ == "__main__":
    unittest.main(verbosity=2)
