import unittest
from anpars.net import NetUtils

class TestNetUtils(unittest.TestCase):
    def test_internet_var_mi(self):
        self.assertIsInstance(NetUtils.internet_var_mi(), bool)

    def test_basit_get_istegi(self):
        sonuc = NetUtils.basit_get_istegi("http://example.com")
        self.assertIsInstance(sonuc, (str, type(None)))

    def test_ip_adresi_al(self):
        ip = NetUtils.ip_adresi_al("example.com")
        self.assertIsInstance(ip, str)
        self.assertRegex(ip, r"\d+\.\d+\.\d+\.\d+")

    def test_port_acik_mi(self):
        self.assertIsInstance(NetUtils.port_acik_mi("example.com", 80), bool)

    def test_url_gecerli_mi(self):
        self.assertTrue(NetUtils.url_gecerli_mi("http://example.com"))
        self.assertFalse(NetUtils.url_gecerli_mi("notaurl"))

    def test_ping_baglantisi_kontrol(self):
        self.assertIsInstance(NetUtils.ping_baglantisi_kontrol("example.com", 80), bool)

if __name__ == "__main__":
    unittest.main(verbosity=2)
