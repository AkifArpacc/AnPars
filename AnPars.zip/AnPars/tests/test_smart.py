import unittest
from anpars.smart import SmartUtils

class TestSmartUtils(unittest.TestCase):
    def test_akilli_donusum(self):
        self.assertIsNone(SmartUtils.akilli_donusum(""))
        self.assertTrue(SmartUtils.akilli_donusum("true"))
        self.assertFalse(SmartUtils.akilli_donusum("false"))
        self.assertEqual(SmartUtils.akilli_donusum("123"), 123)
        self.assertEqual(SmartUtils.akilli_donusum("12.34"), 12.34)
        self.assertEqual(SmartUtils.akilli_donusum("2025-07-10"), 
                         SmartUtils.akilli_donusum("2025-07-10"))  # Date object, just test no exception
        self.assertEqual(SmartUtils.akilli_donusum("{\"a\":1}"), {"a":1})
        self.assertEqual(SmartUtils.akilli_donusum("[1,2,3]"), [1,2,3])
        self.assertEqual(SmartUtils.akilli_donusum("hello"), "hello")

    def test_veri_tipi_bilgisi(self):
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(True), "bool")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(123), "int")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(12.34), "float")
        import datetime
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(datetime.datetime.now()), "datetime")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(datetime.date.today()), "date")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi({"a":1}), "json")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi(None), "none")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi("hello"), "str")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi("123"), "int")
        self.assertEqual(SmartUtils.veri_tipi_bilgisi("[1,2]"), "json")

if __name__ == "__main__":
    unittest.main(verbosity=2)
