import unittest
from anpars.str import StrUtils

class TestStrUtils(unittest.TestCase):

    def test_turkce_karakter_cevir(self):
        self.assertEqual(StrUtils.turkce_karakter_cevir("çalışma"), "calisma")

    def test_metin_temizle(self):
        self.assertEqual(StrUtils.metin_temizle("  Merhaba! Dünya.  "), "Merhaba Dünya")
        self.assertEqual(StrUtils.metin_temizle("Selam @#*&!"), "Selam")

    def test_slugify(self):
        self.assertEqual(StrUtils.slugify("Python Programlama Dili 2025!"), "python-programlama-dili-2025")

    def test_kelime_say(self):
        self.assertEqual(StrUtils.kelime_say("Merhaba dünya!"), 2)

    def test_sesli_harf_say(self):
        self.assertEqual(StrUtils.sesli_harf_say("Merhaba"), 3)

    def test_sessiz_harf_say(self):
        self.assertEqual(StrUtils.sessiz_harf_say("Merhaba"), 4)

    def test_ters_cevir(self):
        self.assertEqual(StrUtils.ters_cevir("abc"), "cba")

    def test_ilk_harf_buyuk(self):
        self.assertEqual(StrUtils.ilk_harf_buyuk("merhaba"), "Merhaba")

    def test_tum_harf_buyuk(self):
        self.assertEqual(StrUtils.tum_harf_buyuk("merhaba"), "MERHABA")

    def test_kelimeleri_ayir(self):
        self.assertEqual(StrUtils.kelimeleri_ayir("Merhaba, dünya!"), ["Merhaba", "dünya"])

    def test_metin_uzunlugu(self):
        self.assertEqual(StrUtils.metin_uzunlugu("abc"), 3)

if __name__ == "__main__":
    unittest.main()
