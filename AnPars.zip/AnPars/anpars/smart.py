import json
import datetime
import re

class SmartUtils:
    @staticmethod
    def akilli_donusum(veri):
        if veri is None:
            return None

        if not isinstance(veri, str):
            return veri

        metin = veri.strip().lower()

        if metin == "" or metin == "null":
            return None
        if metin == "true":
            return True
        if metin == "false":
            return False

        if re.fullmatch(r"[-+]?\d+", metin):
            try:
                return int(metin)
            except:
                pass

        if re.fullmatch(r"[-+]?\d*\.\d+", metin):
            try:
                return float(metin)
            except:
                pass

        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S",
                    "%Y-%m-%d", "%Y/%m/%d"):
            try:
                dt = datetime.datetime.strptime(veri, fmt)
                if fmt in ("%Y-%m-%d", "%Y/%m/%d"):
                    return dt.date()
                else:
                    return dt
            except:
                pass

        if (metin.startswith("{") and metin.endswith("}")) or \
           (metin.startswith("[") and metin.endswith("]")):
            try:
                return json.loads(veri)
            except:
                pass

        return veri

    @staticmethod
    def veri_tipi_bilgisi(veri) -> str:
        import datetime
        if isinstance(veri, bool):
            return "bool"
        elif isinstance(veri, int):
            return "int"
        elif isinstance(veri, float):
            return "float"
        elif isinstance(veri, datetime.datetime):
            return "datetime"
        elif isinstance(veri, datetime.date):
            return "date"
        elif isinstance(veri, dict) or isinstance(veri, list):
            return "json"
        elif veri is None:
            return "none"
        elif isinstance(veri, str):
            val = SmartUtils.akilli_donusum(veri)
            if isinstance(val, str):
                return "str"
            else:
                return SmartUtils.veri_tipi_bilgisi(val)
        return type(veri).__name__
