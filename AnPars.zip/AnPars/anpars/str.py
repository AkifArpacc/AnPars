import re

class StrUtils:
    _TURKCE_TO_ING = {
        'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u',
        'Ç': 'C', 'Ğ': 'G', 'İ': 'I', 'Ö': 'O', 'Ş': 'S', 'Ü': 'U',
    }

    @staticmethod
    def turkce_karakter_cevir(metin: str) -> str:
        return ''.join(StrUtils._TURKCE_TO_ING.get(c, c) for c in metin)

    @staticmethod
    def metin_temizle(metin: str, ozel_karakterleri_kaldir: bool = True) -> str:
        metin = metin.strip()
        metin = re.sub(r'\s+', ' ', metin)
        if ozel_karakterleri_kaldir:
            metin = re.sub(r'[^a-zA-Z0-9ğüşöçıİĞÜŞÖÇ\s]', '', metin)
            metin = metin.strip()  # burada ekle
        return metin



    @staticmethod
    def slugify(metin: str) -> str:
        metin = StrUtils.turkce_karakter_cevir(metin)
        metin = metin.lower().strip()
        metin = re.sub(r'\s+', '-', metin)
        metin = re.sub(r'[^a-z0-9\-]', '', metin)
        metin = re.sub(r'-+', '-', metin)
        return metin

    @staticmethod
    def kelime_say(metin: str) -> int:
        kelimeler = re.findall(r'\b\w+\b', metin)
        return len(kelimeler)

    @staticmethod
    def sesli_harf_say(metin: str) -> int:
        sesli = "aeıioöuüAEIİOÖUÜ"
        return sum(1 for harf in metin if harf in sesli)

    @staticmethod
    def sessiz_harf_say(metin: str) -> int:
        sessiz = "bcçdfgğhjklmnprsştvyzBCÇDFGĞHJKLMNPRSŞTVYZ"
        return sum(1 for harf in metin if harf in sessiz)

    @staticmethod
    def ters_cevir(metin: str) -> str:
        return metin[::-1]

    @staticmethod
    def ilk_harf_buyuk(metin: str) -> str:
        if not metin:
            return metin
        return metin[0].upper() + metin[1:].lower()

    @staticmethod
    def tum_harf_buyuk(metin: str) -> str:
        return metin.upper()

    @staticmethod
    def kelimeleri_ayir(metin: str) -> list[str]:
        metin_temiz = re.sub(r'[^\w\sğüşöçıİĞÜŞÖÇ]', '', metin, flags=re.UNICODE)
        return metin_temiz.strip().split()

    @staticmethod
    def metin_uzunlugu(metin: str) -> int:
        return len(metin)
