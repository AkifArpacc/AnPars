import socket
import urllib.request
import re
from typing import Optional

class NetUtils:
    @staticmethod
    def internet_var_mi(timeout: float = 3.0) -> bool:
        try:
            socket.setdefaulttimeout(timeout)
            socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
            return True
        except OSError:
            return False

    @staticmethod
    def basit_get_istegi(url: str, timeout: float = 5.0) -> Optional[str]:
        try:
            with urllib.request.urlopen(url, timeout=timeout) as response:
                return response.read().decode("utf-8")
        except Exception:
            return None

    @staticmethod
    def ip_adresi_al(hostname: str) -> Optional[str]:
        try:
            return socket.gethostbyname(hostname)
        except socket.error:
            return None

    @staticmethod
    def port_acik_mi(host: str, port: int, timeout: float = 1.0) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except Exception:
            return False

    @staticmethod
    def url_gecerli_mi(url: str) -> bool:
        pattern = re.compile(
            r'^(https?:\/\/)?'
            r'(([a-zA-Z0-9\-_]+\.)+[a-zA-Z]{2,})'
            r'(\/[a-zA-Z0-9\-._~:\/?#[\]@!$&\'()*+,;=]*)?$'
        )
        return bool(pattern.match(url))

    @staticmethod
    def ping_baglantisi_kontrol(host: str, port: int = 80, timeout: float = 1.0) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except Exception:
            return False
