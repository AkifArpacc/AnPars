import os
from pathlib import Path
import shutil
from typing import Optional

class FsUtils:
    @staticmethod
    def klasor_agaci(yol: str, derinlik: int = 2) -> str:
        yol = Path(yol)
        if not yol.exists() or not yol.is_dir():
            return "Geçersiz klasör yolu."

        def _agac(p: Path, level=0):
            if level > derinlik:
                return ""
            agac_str = ""
            for item in sorted(p.iterdir()):
                agac_str += "  " * level + "|-- " + item.name + "\n"
                if item.is_dir():
                    agac_str += _agac(item, level + 1)
            return agac_str

        return _agac(yol)

    @staticmethod
    def otomatik_dosya_ismi_uret(dizin: str, dosya_adi: str) -> str:
        dizin = Path(dizin)
        if not dizin.exists() or not dizin.is_dir():
            raise ValueError("Geçersiz dizin yolu.")

        dosya_adi = Path(dosya_adi)
        isim = dosya_adi.stem
        ext = dosya_adi.suffix
        yeni_adi = dosya_adi.name
        sayac = 1

        while (dizin / yeni_adi).exists():
            yeni_adi = f"{isim}({sayac}){ext}"
            sayac += 1

        return yeni_adi

    @staticmethod
    def dosya_yedekle(dosya_yolu: str, yedek_klasor: str = "yedekler") -> Optional[str]:
        dosya_yolu = Path(dosya_yolu)
        yedek_klasor = Path(yedek_klasor)
        try:
            if not dosya_yolu.exists() or not dosya_yolu.is_file():
                raise FileNotFoundError("Dosya bulunamadı.")

            yedek_klasor.mkdir(parents=True, exist_ok=True)
            yeni_adi = FsUtils.otomatik_dosya_ismi_uret(str(yedek_klasor), dosya_yolu.name)
            hedef = yedek_klasor / yeni_adi
            shutil.copy2(dosya_yolu, hedef)
            return str(hedef)
        except Exception as e:
            print(f"Yedekleme hatası: {e}")
            return None

    @staticmethod
    def dosya_boyutu_okunabilir(dosya_yolu: str) -> str:
        yol = Path(dosya_yolu)
        if not yol.exists() or not yol.is_file():
            raise FileNotFoundError("Dosya bulunamadı.")

        boyut = yol.stat().st_size
        birimler = ["B", "KB", "MB", "GB", "TB"]
        i = 0
        while boyut >= 1024 and i < len(birimler) - 1:
            boyut /= 1024
            i += 1
        # Burada B için boşluk bırak, diğerlerinde de bırakmaya devam et
        return f"{boyut:.2f} {birimler[i]}"

